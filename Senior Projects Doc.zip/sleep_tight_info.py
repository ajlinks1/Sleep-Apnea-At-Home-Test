# import sys


patient_fname = input("Please enter your first name: ")
patient_lname = input("Please enter you last name: ")
patient_address = input("Please enter your home address: ")
patient_birth_date = input("Please enter your birth date (MM-DD-YY): ")
patient_height = input("Please enter your height (X ft. Y in.): ")
patient_weight = input("Please enter you weight in lbs.: ")

print(patient_fname)
print(patient_lname)
print(patient_address)
print(patient_birth_date)
print(patient_height)
print(patient_weight)

f = open("/home/pi/Desktop/sleep_tight_info.txt", "w+")

f.write("Patient First Name: %s\r\n" % (patient_fname))
f.write("Patient Last Name: %s\r\n" % (patient_lname))
f.write("Patient Address: %s\r\n" % (patient_address))
f.write("Patient Birth Date: %s\r\n" % (patient_birth_date))
f.write("Patient Height: %s\r\n" % (patient_height))
f.write("Patient Weight: %s\r\n" % (patient_weight))


doctor_fname = input("Please enter your doctor's first name: ")
doctor_lname = input("Please enter your doctor's last name: ")
doctor_address = input("Please enter your doctor's office's address: ")
doctor_email = input(
    "Please enter your doctor's email address (ex: johndoe@email.com): "
)
doctor_phone = input("Please enter your doctor's phone number (ex: XXX-XXX-XXXX): ")

print(doctor_fname)
print(doctor_lname)
print(doctor_address)
print(doctor_email)
print(doctor_phone)

f.write("Doctor First Name: %s\r\n" % (doctor_fname))
f.write("Doctor Last Name: %s\r\n" % (doctor_lname))
f.write("Doctor Address: %s\r\n" % (doctor_address))
f.write("Doctor Email: %s\r\n" % (doctor_email))
f.write("Doctor Phone Number: %s\r\n" % (doctor_phone))

approved_persons = input(
    "Do you have an approved person that you would like to send your data to? Enter Y for yes or N for no: "
)

if approved_persons == "Y":

    fname = input("Please enter approved persons first name: ")
    lname = input("Please enter approved persons last name: ")
    email = input("Please enter approved persons email(ex: johndoe@email.com): ")
    relation = input("Please enter your approved persons relation to you: ")

    print(fname)
    print(lname)
    print(email)
    print(relation)

    f.write("Approved Persons First Name: %s\r\n" % (fname))
    f.write("Approved Persons Last Name: %s\r\n" % (lname))
    f.write("Approved Persons Email: %s\r\n" % (email))
    f.write("Approved Persons Relation to You: %s\r\n" % (relation))

f.close()

