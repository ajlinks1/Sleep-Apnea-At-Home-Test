import subprocess
import os
import time
import signal
import serial
import keyboard
import sys
from datetime import datetime

loop_continue = True;

ser = serial.Serial('/dev/ttyACM0', 9600)
s = []

print("Press ESC to stop")
print("Heart Rate and Decibel Readings")

now = datetime.now()
current_time = now.strftime("%H:%M:%S")

heart_file = "combined" + current_time + ".txt"
f = open(heart_file, "w")

# text_file = "mic" + current_time + ".txt"
# g = open(text_file, "w")

while loop_continue == True:
    value = ser.readline().decode('ascii')
    data = float(value)
    now = datetime.now()
    current_time = now.strftime("%H:%M:%S")
    
    if value:
        s.append(value)
        print(s)
        print(current_time)
        s = []
        f.writelines("\n")
        f.writelines(value)
        f.writelines("\n")
        f.writelines(current_time)
        
    if keyboard.is_pressed('esc'):
        loop_continue = False
        ser.close()
        f.close()
#         g.close()